import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
	// mode:'history',
  	routes:[
	    {	path: '/', redirect: '/index/home'  },
	    {	
	    	path: '/index',
	    	name: 'index', 
	    	redirect: '/index/home',
	    	component: () => import('@/components/index/index'),
	    	children:[
	    		{	path:'home',name:'home',component: () => import('@/components/index/home/home')	},
	    		{ 	path:'video',name:'video',component: () => import('@/components/index/video/video')	},
	    		{ 	path:'collect',name:'collect',component: () => import('@/components/index/collect/collect')	},
	    		{
	    			path:'my',
	    			name:'my',
	    			redirect: 'my/user',
	    			component: () => import('@/components/index/my/my'),
	    			children:[
	    				{	
	    					path:'user', name:'user', component: () => import('@/components/index/my/user')
	    				},
	    				{	
	    					path:'thirdparty', name:'thirdparty', component: () => import('@/components/index/my/thirdparty')
	    				},
	    				{	
	    					path:'userguide', name:'userguide', component: () => import('@/components/index/my/userguide')
	    				},
	    				{	
	    					path:'my_barcode', name:'my_barcode', component: () => import('@/components/index/my/my_barcode')
	    				},
	    				{	
	    					path:'feedback', name:'feedback', component: () => import('@/components/index/my/feedback')
	    				},
	    			],
	    		},
	    	],
	    },
	    {	path: '/detail', name: 'detail', component: () => import('@/components/detail/detail') 	},
	    {	path: '/search', name: 'search', component: () => import('@/components/search/search')	},
	],
})
