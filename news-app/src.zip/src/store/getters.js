export default {
    indexActive: state => {
        return state.indexActive
    },
    newsColumn: state => {
        return state.newsColumn
    },
}