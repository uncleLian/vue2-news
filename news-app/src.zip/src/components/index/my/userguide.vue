<template>
  <div id="userguide">
    <div class="myheader">
      <!--<div class="iosHeader"></div>-->
      <mt-header title="头条小贴士">
        <router-link to="/" slot="left">
          <mt-button icon="back">返回</mt-button>
        </router-link>
      </mt-header>
    </div>
    <div id="content">

    </div>
  </div>
</template>

<script>
  export default{
    data(){
      return {}
    },
    methods: {},
    computed: {},
    mounted(){

    },
  }
</script>
<style>
</style>
