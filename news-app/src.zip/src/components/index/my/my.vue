<template>
  <div id="my">
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
export default{
    name: 'my',
}
</script>
<style scoped>
  #my {
    width: 100%;
    height: 100%;
    background-color: #e0e0e0;
  }
</style>
