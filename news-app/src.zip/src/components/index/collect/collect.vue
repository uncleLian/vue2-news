<template>
	<div id="collect">
		<div>我是collect页面</div>
	</div>
</template>

<script>
export default{
	name:'collect',
}
</script>

<style scoped>

#collect{
	width: 100%;
	height: 100%;
	overflow: hidden;
}
</style>