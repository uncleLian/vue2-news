<template>
  <div id="navBar">
    <mt-tabbar fixed v-model="selected">
      <mt-tab-item id="home">
        <img slot="icon" src="../../assets/icon/home.png">
        主页
      </mt-tab-item>
      <mt-tab-item id="video">
        <img slot="icon" src="../../assets/icon/video.png">
        视频
      </mt-tab-item>
      <mt-tab-item id="collect">
        <img slot="icon" src="../../assets/icon/shouchang.png">
        收藏
      </mt-tab-item>
      <mt-tab-item id="my">
        <img slot="icon" src="../../assets/icon/my.png">
        个人
      </mt-tab-item>
    </mt-tabbar>
  </div>
</template>

<script>
  export default{
    name: 'navbar',
    data(){
      return {
        selected:'home',
      }
    },
    watch: {
      selected(val){
        this.$router.push(`/index/${val}`);
      }
    }
  }
</script>
<style>

</style>
