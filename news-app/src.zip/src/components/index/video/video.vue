<template>
	<div id="video">
		<div>我是video页面</div>
	</div>
</template>

<script>
export default{
	name:'video',
}
</script>

<style scoped>

#video{
	width: 100%;
	height: 100%;
	overflow: hidden;
}
</style>