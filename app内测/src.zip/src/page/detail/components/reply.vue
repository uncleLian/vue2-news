<template>
    <transition name='fadeIn'>
        <div id='reply' v-if='visible'>
            <my-header fixed title='回复'>
                <a slot='left' @click.stop="visible = false"><i class="icon-close"></i></a>
            </my-header>
            <div class="content" :class="{isIOS: $store.state.device == 'ios'}">
                <div class="container">
                    <div class="reply-full">
                        <comment-item :itemJson='replyJson'></comment-item>
                    </div>
                    <div class="reply-hot">
                        <h2>热门评论</h2>
                        <comment-item v-for='item in reply_hot' :itemJson='item' @click.native.stop="" :key='item'></comment-item>
                    </div>
                    <div class="reply-all">
                        <h2>全部评论</h2>
                        <comment-item v-for='item in reply_all' :itemJson='item' @click.native.stop="" :key='item'></comment-item>
                    </div>
                </div>
            </div>
        </div>
    </transition>
</template>
<script>
import commentItem from './commentItem'
export default {
    props: {
        replyJson: {
            default: ''
        }
    },
    components: {
        commentItem
    },
    data() {
        return {
            visible: false,
            reply_hot: [{
                name: '145222222222222222222222222222223',
                zan: 221,
                text: '哈哈哈哈哈哈不错哦',
                time: '3小时之前',
                img: 'https://tvax1.sinaimg.cn/crop.0.0.498.498.180/006tpHokly8fhejurawwtj30du0dudg1.jpg'
            }, {
                name: '143623',
                zan: 2641,
                text: '哈哈哈哈哈哈dwa带娃大无多无阿达瓦大洼地挖的挖的挖的挖的洼地哇吊袜带哇带娃带娃带娃带娃带娃发瓦房瓦房瓦房瓦房瓦房瓦房瓦房瓦房玩不错哦',
                time: '40小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.10.0.492.492.180/5ddbc59dly8fewqfv6hqnj20e80dogma.jpg'
            }, {
                name: '136323',
                zan: 41,
                text: '哈哈哈哈哈哈不错哦',
                time: '5小时之前',
                img: 'https://tvax4.sinaimg.cn/crop.0.26.1242.1242.180/0065HvrLly8fgugsuk0zxj30yi0zydhy.jpg'
            }, {
                name: '12363',
                zan: '',
                text: '哈哈哈哈哈哈不错哦',
                time: '16小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'
            }],
            reply_all: [{
                name: '145222222222222222222222222222223',
                zan: 221,
                text: '哈哈哈哈哈哈不错哦',
                time: '3小时之前',
                img: 'https://tvax1.sinaimg.cn/crop.0.0.498.498.180/006tpHokly8fhejurawwtj30du0dudg1.jpg'
            }, {
                name: '143623',
                zan: 2641,
                text: '哈哈哈哈哈哈dwa带娃大无多无阿达瓦大洼地挖的挖的挖的挖的洼地哇吊袜带哇带娃带娃带娃带娃带娃发瓦房瓦房瓦房瓦房瓦房瓦房瓦房瓦房玩不错哦',
                time: '40小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.10.0.492.492.180/5ddbc59dly8fewqfv6hqnj20e80dogma.jpg'
            }, {
                name: '136323',
                zan: 41,
                text: '哈哈哈哈哈哈不错哦',
                time: '5小时之前',
                img: 'https://tvax4.sinaimg.cn/crop.0.26.1242.1242.180/0065HvrLly8fgugsuk0zxj30yi0zydhy.jpg'
            }, {
                name: '12363',
                zan: '',
                text: '哈哈哈哈哈哈不错哦',
                time: '16小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'
            }, {
                name: '12363',
                zan: '',
                text: '哈哈哈哈哈哈不错哦',
                time: '16小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'
            }, {
                name: '12363',
                zan: '',
                text: '哈哈哈哈哈哈不错哦',
                time: '16小时之前',
                img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'
            }]
        }
    },
    computed: {

    },
    methods: {
        open() {
            this.visible = true
        }
    },
    mounted() {

    }
}
</script>
<style scoped lang='stylus'>
#reply {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 100%;
    overflow: hidden;
    z-index: 1000;
    .content {
        height: 100%;
        padding-top: 44px;
        background-color: #f8f8f8;
        &.isIOS {
            padding-top: 64px;
        }
        .container {
            height: 100%;
            overflow: auto;
            position: relative;
            -webkit-overflow-scrolling: touch;
            h2 {
                display: inline-block;
                font-size: 14px;
                margin: 10px 0 0 16px;
                padding-bottom: 10px;
                font-weight: 400;
            }
            .reply-full {
                border-bottom: 1px solid #ddd;
            }
        }
    }
}
</style>
