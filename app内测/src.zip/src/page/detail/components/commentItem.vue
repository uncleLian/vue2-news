<template>
    <section class='comment_item'>
        <div class="item_portrait">
            <img :src="itemJson.img">
        </div>
        <div class="item_content">
            <div class="content_top">
                <span class="name">{{itemJson.name}}</span>
                <span class="zan icon-zan" @click.stop='addZan' :class="{'active': zan}"> {{itemJson.zan}}</span>
            </div>
            <div class="content_text">{{itemJson.text}}</div>
            <div class="content_footer">
                <span class="time">{{itemJson.time}}</span>
                <span class="reply"> · 回复</span>
            </div>
        </div>
    </section>
</template>
<script>
export default {
    props: {
        itemJson: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            zan: false
        }
    },
    methods: {
        addZan() {
            if (!this.zan) {
                this.itemJson.zan++
                this.zan = true
            }
        }
    }
}
</script>
<style scoped lang='stylus'>
.comment_item {
    position: relative;
    padding: 16px;
    .item_portrait {
        float: left;
        width: 36px;
        height: 36px;
        overflow: hidden;
        border-radius: 100%;
        img {
            width: 100%;
        }
    }
    .item_content {
        padding-left: 46px;
        font-size: 14px;
        color: #000;
        .content_top {
            display: flex;
            width: 100%;
            margin-bottom: 6px;
            line-height: 16px;
            .name {
                flex: 1;
                color: #007aff;
                overflow: hidden;
                text-align: left;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                padding-right: 10px;
            }
            .zan {
                color: #888;
                text-align: right;
                vertical-align: middle;
                &.active {
                    color: #d81e06;
                }
            }
        }
        .content_text {
            margin-bottom: 6px;
        }
        .content_footer {
            margin-bottom: 6px;
            font-size: 12px;
        }
    }
}
</style>
