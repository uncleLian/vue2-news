<detail-share ref='share' :detailJson='currentArticle'></detail-share>
<template>
    <div id="detail">
        <my-header fixed>
            <a slot="left" @click.stop='$router.go(-1)'><i class="icon-back"></i></a>
            <a slot="mid" @click.stop='goTop'>{{title}}</a>
            <a slot="right" @click.stop='$refs.share.toggle()'><i class="icon-more"></i></a>
        </my-header>
        <div class="content" :class="{isIOS: $store.state.device == 'ios'}">
            <div class="container" v-swiper:swiperRight='true'>
                <!-- 文章 -->
                <detail-article class='article' :json='currentArticle'></detail-article>
                <!-- 标签 -->
                <detail-tags class='tag' :json='currentArticle.infotags'></detail-tags>
                <!-- 喜欢 -->
                <detail-eva class='evaluate' :num="currentArticle.diggtop" :like="currentArticle.giveup" :collect='currentArticle.collect'></detail-eva>
                <!--  推荐 -->
                <detail-recommend class='recommend' :json='recommendJson'></detail-recommend>

                <!-- 评论 -->
                <div class='comment'>
                    <comment-item v-for='item in commentJson' :itemJson='item' @click.native.stop="openReply(item)" :key='item'></comment-item>
                </div>
                
                <div class="review">
                    <div class="left">
                        <div class="input_box">
                            <i class="icon-edit"></i>
                            <span>写评论</span>
                        </div>
                    </div>
                    <div class="right">
                        <a class="comment_btn"><i class="icon-comment"></i></a><a class="collect_btn"><i class="icon-collect"></i></a><a class="share_btn" @click.stop='$refs.share.toggle()'><i class="icon-share"></i></a>
                    </div>
                </div>

                <loading :visible='loading'></loading>

                <error fixed :visible='error' :method='init'></error>
            </div>
        </div>
        <!-- 分享 -->
        <detail-share :detailJson='currentArticle' ref="share"></detail-share>

        <detail-reply :replyJson="replyJson" ref="reply"></detail-reply>

    </div>
</template>
<script>
import detailArticle from './components/article'
import detailTags from './components/tags'
import detailRecommend from './components/recommend'
import detailShare from './components/share'
import detailEva from './components/evaluate'
import commentItem from './components/commentItem'
import detailReply from './components/reply'
import {mapGetters, mapMutations, mapActions} from 'vuex'
export default {
    name: 'detail',
    components: {
        detailArticle,
        detailTags,
        detailRecommend,
        detailShare,
        detailEva,
        commentItem,
        detailReply
    },
    data() {
        return {
            commentJson: [
                {name: '145222222222222222222222222222223', zan: 221, text: '哈哈哈哈哈哈不错哦', time: '3小时之前', img: 'https://tvax1.sinaimg.cn/crop.0.0.498.498.180/006tpHokly8fhejurawwtj30du0dudg1.jpg'},
                {name: '143623', zan: 2641, text: '哈哈哈哈哈哈dwa带娃大无多无阿达瓦大洼地挖的挖的挖的挖的洼地哇吊袜带哇带娃带娃带娃带娃带娃发瓦房瓦房瓦房瓦房瓦房瓦房瓦房瓦房玩不错哦', time: '40小时之前', img: 'https://tvax3.sinaimg.cn/crop.10.0.492.492.180/5ddbc59dly8fewqfv6hqnj20e80dogma.jpg'},
                {name: '136323', zan: 41, text: '哈哈哈哈哈哈不错哦', time: '5小时之前', img: 'https://tvax4.sinaimg.cn/crop.0.26.1242.1242.180/0065HvrLly8fgugsuk0zxj30yi0zydhy.jpg'},
                {name: '12363', zan: '', text: '哈哈哈哈哈哈不错哦', time: '16小时之前', img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'},
                {name: '12363', zan: '', text: '哈哈哈哈哈哈不错哦', time: '16小时之前', img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'},
                {name: '12363', zan: '', text: '哈哈哈哈哈哈不错哦', time: '16小时之前', img: 'https://tvax3.sinaimg.cn/crop.0.0.749.749.180/9312e9a6ly8fh1pg49olaj20ku0ktt9b.jpg'}
            ],
            replyJson: '',
            id: null,
            classid: null,
            from: '',
            title: '健康头条',
            currentArticle: {}, // 文章数据
            recommendJson: [], // 推荐数据
            enterTime: '',
            leaveTime: '',
            loading: true,
            error: false
        }
    },
    computed: {
        ...mapGetters('index', [
            'indexColumn'
        ]),
        ...mapGetters('detail', [
            'datafrom'
        ]),
        ...mapGetters([
            'userid'
        ])
    },
    methods: {
        ...mapMutations('detail', [
            'set_datafrom'
        ]),
        ...mapActions('index', [
            'get_indexColumn_data'
        ]),
        ...mapActions('detail', [
            'get_Article_data',
            'get_Recommend_data',
            'send_user_data'
        ]),
        goTop() {
            $('#detail .container').animate({scrollTop: 0})
        },
        async init() {
            this.classid = this.$route.query.classid
            this.id = this.$route.query.id
            this.from = this.$route.query.datafrom
            this.set_datafrom(this.$route.query.datafrom)
            $('#detail .container').scrollTop(0)
            if (!(this.indexColumn.length > 1)) {
                await this.get_indexColumn_data()
            }
            let index = this.indexColumn.findIndex(n => n.classid === this.classid)
            if (index > -1) {
                this.title = `健康头条 · ${this.indexColumn[index].classname}`
            }
            this.get_Article() // 获取 文章数据
            this.get_Recommend() // 获取 推荐数据
        },
        get_Article() {
            this.loading = true
            this.enterTime = new Date().getTime()
            this.get_Article_data({'id': this.id, 'datafrom': this.from})
            .then(res => {
                if (res) {
                    this.currentArticle = res
                    this.loading = false
                }
                this.error = false
            })
            .catch(err => {
                console.log(err)
                this.error = true
                this.loading = false
            })
        },
        get_Recommend() {
            this.get_Recommend_data({'classid': this.classid, 'id': this.id})
            .then(res => {
                if (res) {
                    this.recommendJson = res
                }
            })
            .catch(err => {
                console.log(err)
            })
        },
        openReply(item) {
            this.$refs.reply.open()
            this.replyJson = item
        }
    },
    watch: {
        $route(val) {
            if (val.query.id) {
                this.init()
            }
        }
    },
    mounted() {
        this.init()
    },
    beforeRouteLeave(to, from, next) {
        let params = {
            'userid': this.userid,
            'id': this.id,
            'entertime': this.enterTime,
            'leavetime': new Date().getTime(),
            'datafrom': this.datafrom
        }
        this.send_user_data(params)
        next()
    }
}
</script>
<style lang='stylus'>
#detail .content.isIOS {
    padding-top: 64px;
}

#detail {
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #fff;
    header {
        background: #fdfdfd;
        color: #333;
        font-size: 16px;
        border-bottom: 1px solid #ddd;
        i {
            font-size: 20px;
            vertical-align: middle;
        }
    }
    .content {
        width: 100%;
        height: 100%;
        padding-top: 44px;
        position: relative;
        .container {
            height: 100%;
            overflow: auto;
            position: relative;
            -webkit-overflow-scrolling: touch;
        }
        .article {
            padding: 0 16px;
        }
        .tag {
            margin: 20px 0;
        }
        .evaluate {
            margin: 30px 0;
        }
        .recommend {
            margin-top: 10px;
        }
        .comment {
            margin: 20px 0;
        }
        .review{
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 666;
            height: 48px;
            line-height: 48px;
            display: flex;
            background: #fdfdfd;
            border-top: 1px solid #ddd;
            padding: 0 16px;
            .left{
                flex: 1;
                .input_box{
                    width: 100%;
                    height: 32px;
                    line-height: 32px;
                    margin: 8px 0;
                    padding-left: 10px;
                    border-radius: 30px;
                    border: 1px solid #ddd;
                    background: #eee;
                    position: relative;
                    .box_text{
                        position: absolute;
                    }
                }
            }
            .right{
                flex: 1;
                text-align: right;
                a{
                    display: inline-block;
                    text-align: center;
                    width: 33%;
                    padding-left: 10px;
                    font-size: 20px;
                }
            }
        }
    }
}
</style>
